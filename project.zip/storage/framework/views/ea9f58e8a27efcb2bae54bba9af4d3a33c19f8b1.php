<!-- <?php echo e($debugpath); ?> -->



<?php $__env->startSection('title', 'Homepage'); ?>


<?php $__env->startSection('type','home '); ?>


<?php $__env->startSection('description', 'Homepage'); ?>


<?php $__env->startSection('headeranimation'); ?>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/network-animation.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(URL::asset('js/network-animation-init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>