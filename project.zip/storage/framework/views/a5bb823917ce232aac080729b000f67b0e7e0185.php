<!-- <?php echo e($debugpath); ?> -->



<?php $__env->startSection('title', 'Homepage'); ?>


<?php $__env->startSection('type','home '); ?>


<?php $__env->startSection('description', 'Homepage'); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>