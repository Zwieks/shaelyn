<!-- <?php echo e($debugpath); ?> -->
<div class="particles-animation-wrapper">
	<div class="particles-content-wrapper">
		<img src="<?php echo e(asset('img/logo-small-white.svg')); ?>">
		<h2 class="logo-text"><?php echo e(Lang::get('global.name')); ?></h2>
		<p><?php echo e(Lang::get('global.intro')); ?></p>
	</div>
	<div id="particles-js" class="particles-animation"></div>
</div>