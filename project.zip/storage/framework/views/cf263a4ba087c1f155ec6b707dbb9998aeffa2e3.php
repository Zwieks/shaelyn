<!DOCTYPE html>
    <html lang='<?php echo e($locale); ?>' itemscope itemtype= <?php if($type === 'homepage'): ?> "http://schema.org/WebSite" <?php else: ?> "http://schema.org/WebPage" <?php endif; ?>>
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">

        <?php echo $__env->make('pages.basicpage.head-meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->make('pages.basicpage.head-socials', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <link rel="stylesheet" href="<?php echo e(URL::asset('css/site.css')); ?>" type="text/css" media="screen">
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300,600' rel='stylesheet' type='text/css'>
        
        <title><?php echo $__env->yieldContent('title'); ?></title>
    </head>
    <body <?php if(Request::path() === '/'): ?> itemscope itemtype="http://schema.org/WebSite"<?php endif; ?> class="component-<?php echo $__env->yieldContent('type'); ?><?php if (! empty(trim($__env->yieldContent('heroimage')))): ?> has-bgimage <?php endif; ?> <?php if(Auth::check()): ?>logedin <?php endif; ?> preload">
       <!--  heading for document outline  -->
        <h2 class="hide-from-layout"><?php echo $__env->yieldContent('title'); ?></h2>

        <!-- Responsive navigation trigger -->
        <input type="checkbox" id="js-nav-trigger" class="nav-trigger">

        <div class="page-website-wrapper">
            <?php echo $__env->make('pages.basicpage.wrapper', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <?php if (! empty(trim($__env->yieldContent('sticky-content')))): ?>
            <?php echo $__env->yieldContent('sticky-content'); ?>
        <?php endif; ?>

        <div class="page-mobile-nav-container">
            <label class="nav-toggle" id="js-nav-toggle" for="js-nav-trigger"><span class="wrapper"><span></span></span><strong>{_ 'Menu'}</strong></label>
            <div class="nav-wrapper" id="js-nav-wrapper"></div>
            <div class="nav-closer" id="js-nav-closer"></div>
        </div>

        <!-- JAVASCRIPT -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

        <?php echo $__env->make('pages.basicpage.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>