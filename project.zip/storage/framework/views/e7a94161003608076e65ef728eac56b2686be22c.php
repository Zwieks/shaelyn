<!-- <?php echo e($debugpath); ?> -->
<?php if(Auth::check()): ?>
	<?php echo $__env->make('pages.homepage.loggedin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
	<?php echo $__env->make('pages.homepage.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>