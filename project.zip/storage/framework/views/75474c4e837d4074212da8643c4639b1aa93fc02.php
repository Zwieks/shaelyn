<!-- <?php echo e($debugpath); ?> -->
<main class="page-wrapper">
	<?php if (! empty(trim($__env->yieldContent('heroimage')))): ?>
		<?php echo $__env->yieldContent('heroimage'); ?>
	<?php endif; ?>

	<article class="inner">
		<div class="page-content page-overview">
			<?php if (! empty(trim($__env->yieldContent('content')))): ?>
				<div class="page-middle">
					<?php echo $__env->make('pages.basicpage.page-meta', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<h1 itemprop="name" class="seo-title"><?php echo $__env->yieldContent('title'); ?></h1>

					<?php echo $__env->yieldContent('content'); ?>
				</div>
			<?php endif; ?>

			<?php if (! empty(trim($__env->yieldContent('right')))): ?>
				<aside class="page-right">
					<?php echo $__env->yieldContent('right'); ?>
				</aside>
			<?php endif; ?>

			<?php if (! empty(trim($__env->yieldContent('left')))): ?>
				<aside class="page-left">
					<?php echo $__env->yieldContent('left'); ?>
				</aside>
			<?php endif; ?>
		</div>
	</article>
</main>