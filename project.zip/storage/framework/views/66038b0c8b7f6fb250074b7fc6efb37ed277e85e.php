<!-- <?php echo e($debugpath); ?> -->
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta name="description" content="<?php echo e(Lang::get('basicpage.description')); ?>" />
<meta name="keywords" content="<?php echo e(Lang::get('basicpage.keywords')); ?>" />
	

<!-- TODO: GOOGLE SITE VERTIFICATION-->					
<!-- <meta name="google-site-verification" content="x9J0vZlbcPlI2O4qge54Ccbi7_94MbeZ0nPfSZpKzsg" /> -->
		
<link rel="canonical" href="<?php echo e(Request::path()); ?>" />
<meta name="robots" content="index, follow" /> 