<!-- <?php echo e($debugpath); ?> -->
<div class='component-full comp-roadmap' id="roadmap">
	<div class="inner parallax-wrapper inviewelement slideintop">
		<section class="roadmap-intro">
			<h2><?php echo e(Lang::get('roadmap.title')); ?></h2>
			<p><?php echo e(Lang::get('roadmap.description')); ?></p>
		</section>

		<div class="roadmap-itemwrapper">
			<?php $__currentLoopData = Lang::get('roadmap.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roadmap => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="roadmap-item <?php echo e($item['done']); ?>">
					<div class="image-wrapper">
						<figure>
							<img src="<?php echo e(asset('img/markers/' . $item['image'] . '.svg')); ?>">
						</figure>

						<div class="date-wrapper">
							<span class="month"><?php echo e($item['month']); ?></span>
							<span class="year"><?php echo e($item['year']); ?></span>
						</div>
					</div>

					<div class="road-wrapper">
						<div class="roadmap-icon" data-icon="<?php echo e($item['icon']); ?>"></div>
						<div class="filler"></div>
					</div>	

					<section class="content-wrapper">
						<h3><?php echo e($item['title']); ?></h3>
						<p><?php echo e($item['description']); ?></p>
					</section>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
		</div>	
	</div>
</div>