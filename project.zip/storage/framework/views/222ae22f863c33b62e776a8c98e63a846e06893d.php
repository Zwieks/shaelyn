<!-- <?php echo e($debugpath); ?> -->
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.browser.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.viewport.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.header.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.inav.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.animating-labels.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.form-improvement.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.zoom-images.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.grid.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.breadcrumb.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.youtube.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.scrolldepth.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.tracking.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.acties.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.forms.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.parallax.js')); ?>"></script>

<?php if (! empty(trim($__env->yieldContent('headeranimation')))): ?>
	<?php echo $__env->yieldContent('headeranimation'); ?>
<?php endif; ?>