<!-- <?php echo e($debugpath); ?> -->
<footer class="page-footer">
	<ul class="footer-credits">
		<li><a href="<?php echo e(Lang::get('global.url')); ?>" target="_blank"><?php echo e(Lang::get('footer.credits')); ?></a></li>
	</ul>
</footer>