<!-- <?php echo e($debugpath); ?> -->
<meta itemprop="image" content="<?php echo e(URL::asset('img/logo.svg')); ?> ">
<meta itemprop="headline" content="<?php echo $__env->yieldContent('title'); ?>">

<meta itemprop="url" content="<?php echo e(Request::url()); ?>">
<meta itemprop="keywords" content="<?php echo e(Lang::get('basicpage.keywords')); ?>">

<span itemscope itemtype="http://schema.org/Organization">
	<meta itemprop="logo" content="<?php echo e(URL::asset('img/logo.svg')); ?>">
	<meta itemprop="url" content="<?php echo e(Request::url()); ?>">
	<meta itemprop="streetAddress" content="<?php echo e($globals->adress); ?>">
	<meta itemprop="postalCode" content="<?php echo e($globals->postcode); ?>">
	<meta itemprop="addressLocality" content="<?php echo e($globals->city); ?>">
	<meta itemprop="addressCountry" content="<?php echo e($globals->country); ?>">
	<meta itemprop="telephone" content="<?php echo e($globals->phone); ?>">
	<meta itemprop="email" content="<?php echo e($globals->email); ?>">

	<?php if(isset($globals->twitter) && $globals->twitter != ''): ?>
		<meta itemprop="sameAs" content="<?php echo e($globals->twitter); ?>">
	<?php endif; ?>

	<?php if(isset($globals->linkedin) && $globals->linkedin != ''): ?>
		<meta itemprop="sameAs" content="<?php echo e($globals->linkedin); ?>">
	<?php endif; ?>

	<?php if(isset($globals->facebook) && $globals->facebook != ''): ?>
		<meta itemprop="sameAs" content="<?php echo e($globals->facebook); ?>">
	<?php endif; ?>

	<?php if(isset($globals->youtube) && $globals->youtube != ''): ?>
		<meta itemprop="sameAs" content="<?php echo e($globals->youtube); ?>">
	<?php endif; ?>		

	<?php if(isset($globals->instagram) && $globals->instagram != ''): ?>
		<meta itemprop="sameAs" content="<?php echo e($globals->instagram); ?>">
	<?php endif; ?>
</span>