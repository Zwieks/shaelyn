<!-- <?php echo e($debugpath); ?> -->
<div class="home-wrapper">
	
	<?php echo $__env->make('pages.homepage.templates.intro', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	<?php echo $__env->make('pages.homepage.templates.getapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	<?php echo $__env->make('pages.homepage.templates.highlights', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	
	<?php echo $__env->make('pages.homepage.templates.roadmap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	
	<?php echo $__env->make('pages.homepage.templates.contact', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>