<!-- <?php echo e($debugpath); ?> -->
<header class="page-header">
	<div class="inner">
		<figure class="page-logo">
			 <a href="/" title="<?php echo e(Lang::get('basicpage.logotitle')); ?>">
				<img src="<?php echo e(asset('img/logo-small-white.svg')); ?>" alt="Logo <?php echo e(Lang::get('global.name')); ?>">
				<span class="logo-text"><?php echo e(Lang::get('global.name')); ?></span>
			 </a>
		</figure>

		<?php echo $__env->make('pages.basicpage.navmain', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</div>	
</header>