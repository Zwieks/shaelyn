<!-- <?php echo e($debugpath); ?> -->
<div class='component-full empty comp-contact' id="contact">
	<div class="inner parallax-wrapper inviewelement slideinleft">
		<section class="contact-intro">
			<h2><?php echo e(Lang::get('contact.title')); ?></h2>
			<p><?php echo e(Lang::get('contact.description')); ?></p>
		</section>

		<div class="social-wrapper">
			<?php $__currentLoopData = Lang::get('contact.items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socials => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<a href="<?php echo e($item['url']); ?>" class="social-item" title="<?php echo e($item['title']); ?>">
					<img src="<?php echo e(asset('img/socials/' . $item['image'] . '.svg')); ?>">
				</a>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
		</div>
	</div>
</div>	