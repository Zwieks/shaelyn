<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GlobalInfo extends Model
{
    //
}
