<!-- {{$debugpath}} -->
<div class='component-full comp-getapp' id="download">
	<div class="inner parallax-wrapper">
		<section>
			<h2>Get Shaelyn today</h2>
			<h3>Download the app here</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.</p>
		</section>	

		<figure>
			<img src="{{ asset('img/mobile-screens.png') }}">
		</figure>
	</div>
</div>