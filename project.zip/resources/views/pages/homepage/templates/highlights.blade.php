<!-- {{$debugpath}} -->
<div class='component-full empty comp-highlights' id="highlights">
	<div class="inner parallax-wrapper inviewelement slideinleft">
		<section class="highlights-intro">
			<h2>Get Shaelyn today</h2>
			<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.</p>
		</section>

		<div class="hightlight-wrapper inviewelement slideinright">
			<section class="hightlight-item">
				<figure>
					<img src="{{ asset('img/003-technology.svg') }}">
				</figure>	
				<h2>Easy to use</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.</p>
			</section>	

			<section class="hightlight-item">
				<figure>
					<img src="{{ asset('img/002-sand-clock.svg') }}">
				</figure>	
				<h2>Realtime</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.</p>
			</section>

			<section class="hightlight-item">
				<figure>
					<img src="{{ asset('img/001-paper-plane.svg') }}">
				</figure>	
				<h2>Sharing</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.</p>
			</section>
		</div>	
	</div>
</div>	