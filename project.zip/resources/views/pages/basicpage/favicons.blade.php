<!-- {{$debugpath}} -->
{*
	@TODO: Generate all icons with: http://realfavicongenerator.net/
	Place them in the root of the project!
	Don't forget to rename the site name in 'manifest.json'
*}
{*<link rel="shortcut icon" href="/favicon.png" type="image/ico">*}