<!-- {{$debugpath}} -->
<footer class="page-footer">
	<ul class="footer-credits">
		<li><a href="{{Lang::get('global.url')}}" target="_blank">{{ Lang::get('footer.credits') }}</a></li>
	</ul>
</footer>