<?php

return [
    'title' => "Get involved",
    'description' => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed consequat sapien turpis. Duis sed ex in orci vulputate pellentesque. Mauris sollicitudin nibh in laoreet dapibus.",
    'items' => [
         [
            'title' => 'Find us on Twitter',
            'image' => "twitter",
            'url' => "/twitter",
        ],
         [
            'title' => 'Find us on Facebook',
            'image' => "Facebook",
            'url' => "/Facebook",
        ],
        [
            'title' => 'Find us on Reddit',
            'image' => "Reddit",
            'url' => "/Reddit",
        ],
        [
            'title' => 'Find us on Instagram',
            'image' => "instagram",
            'url' => "/instagram",
        ],
        [
            'title' => 'Find us on YouTube',
            'image' => "youtube",
            'url' => "/youtube",
        ],
        [
            'title' => 'Email us',
            'image' => "email",
            'url' => "mailto:info@shaelyn.io",
        ],
    ],
];