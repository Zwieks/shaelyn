<?php

return [
    'credits' => "&copy; 2018 Shealyn &bull; All Rights Reserved",
];