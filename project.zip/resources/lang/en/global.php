<?php

return [
    'name' => 'Shaelyn',
    'title' => 'Shaelyn the social feeds app',
    'url' => 'shaelyn.io',
    'keywords' => '',
    'slogan' => 'Get your feeds up!',
    'logotitle' => 'Go to homepage',
    'mainnavtitle' => 'Main navigation',
    'titlemainnav' => 'Home',
    'description' => 'Simply the best social feed sharing app there is',

    'mail-webmaster' => 'webmaster@shaelyn.nl',
    'mail-info' => 'info@shaelyn.nl',

    'footercredits' => '© 2016 - realisation by Shaelyn',
    'seo-footertitle' => 'Secondary navigation',

    'intro' => 'Nullam dictum mattis diam ac efficitur. Etiam non interdum nibh. Vivamus nec ex elit. Nunc eget pulvinar sem, et convallis dolor. Donec ac sollicitudin purus. Suspendisse mollis mauris sem, non cursus nulla faucibus ut. Pellentesque sed elit tortor. Donec imperdiet.',
];